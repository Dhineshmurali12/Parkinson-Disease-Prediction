#  Parkinson's Disease Prediction using SVM

This project aims to detect Parkinson’s Disease from biomedical voice measurements using a Support Vector Machine (SVM) classifier. The dataset contains 22 extracted features from voice recordings of individuals, and the model is trained to classify whether the subject has Parkinson’s or not.

---

##  Table of Contents

- [Overview](#overview)
- [Dataset](#dataset)
- [Libraries Used](#libraries-used)
- [Data Preprocessing](#data-preprocessing)
- [Model Building](#model-building)
- [Evaluation](#evaluation)
- [Prediction](#prediction)
- [Improvements](#improvements)
- [How to Run](#how-to-run)
- [Results](#results)
- [License](#license)

---

##  Overview

Parkinson’s Disease is a progressive disorder of the nervous system. It affects movement and speech. By analyzing vocal frequency characteristics, we aim to build a predictive model using **SVM** to help with early-stage detection.

---

##  Dataset

- **Source**: [UCI Parkinson's Dataset](https://archive.ics.uci.edu/ml/datasets/parkinsons)
- **Records**: 195 instances
- **Features**: 23 (22 features + 1 target)
- **Target Variable**: `status` (1 = Parkinson's, 0 = Healthy)

---

## Code

```python

## Libraries Used

import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
from sklearn.metrics import classification_report, accuracy_score

## Data Preprocessing

Removed irrelevant columns like `name`.  
Split into features `X` and target `y`.  
Scaled the features using `StandardScaler`.

```python
import pandas as pd
from sklearn.preprocessing import StandardScaler

df = pd.read_csv("parkinsons.csv")
df.drop(columns=["name"], inplace=True)

X = df.drop("status", axis=1)
y = df["status"]

scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)


## Model Building
Used Support Vector Classifier (SVC) with rbf kernel, adjusted C, and added class_weight.

```python
from sklearn.svm import SVC

svm_model = SVC(kernel='rbf', C=0.5, gamma='scale', class_weight='balanced', random_state=42)
svm_model.fit(X_train, y_train)

## Evaluation

```python
y_pred = svm_model.predict(X_test)

print("Accuracy:", accuracy_score(y_test, y_pred))
print("Classification Report:\n", classification_report(y_test, y_pred))

## Sample Output:

```python
Accuracy: 0.90

Classification Report:
               precision    recall  f1-score   support
           0       0.80      0.73      0.76        11
           1       0.92      0.95      0.94        38

## Prediction
Predicting whether a patient has Parkinson’s based on new input:

```python
sample_input = {
    'MDVP:Fo(Hz)': 110.0, 'MDVP:Fhi(Hz)': 150.0, 'MDVP:Flo(Hz)': 70.0,
    'MDVP:Jitter(%)': 0.007, 'MDVP:Jitter(Abs)': 0.0032, 'MDVP:RAP': 0.0085,
    'MDVP:PPQ': 0.0048, 'Jitter:DDP': 0.0049, 'MDVP:Shimmer': 0.0123,
    'MDVP:Shimmer(dB)': 0.0028, 'Shimmer:APQ3': 0.014, 'Shimmer:APQ5': 0.017,
    'MDVP:APQ': 0.030, 'Shimmer:DDA': 0.028, 'NHR': 0.017, 'HNR': 0.020,
    'RPDE': 0.049, 'DFA': 0.008, 'spread1': 0.013, 'spread2': 0.010,
    'D2': 0.220, 'PPE': 0.310
}

sample_df = pd.DataFrame([sample_input])
scaled_input = scaler.transform(sample_df)
print("Prediction:", svm_model.predict(scaled_input))

## Improvements
Handled class imbalance using class_weight='balanced'

Tuned hyperparameters like C and gamma

Improved precision and recall for class 0 (healthy)

